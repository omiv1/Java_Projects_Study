package zadanie_9_3_Lukasz_Oleksiuk;

import java.io.*;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class Cezar {

    private static final int ROZMIAR_ALFABETU = 'z' - 'a' + 1;
    private static final int PRZESUNIECIE = 3;

    public static void main(String[] args) throws IOException {
        File plik_in = new File("plik_in_od.txt");
        File plik_out = new File("plik_out_za.txt");
        Scanner in = new Scanner(plik_in);
        BufferedWriter writer = new BufferedWriter(new FileWriter(plik_out));
        ArrayList<String> wiersze = new ArrayList<String>();
        ArrayList<String> zaszyfrowany = new ArrayList<String>();
        ArrayList<String> odszyfrowany = new ArrayList<String>();
        ArrayList<Boolean> palindrom = new ArrayList<Boolean>();
        while (in.hasNextLine())
        {
            wiersze.add(in.nextLine());
        }
        in.close();
        for(String wiersz : wiersze)
        {
            zaszyfrowany.add(szyfruj(wiersz,PRZESUNIECIE));
        }
        for(String wiersz : zaszyfrowany)
        {
            odszyfrowany.add(odszyfruj(wiersz,PRZESUNIECIE));
        }
        for(String wiersz : wiersze)
        {
            palindrom.add(czyJestPalindromem(wiersz));
        }
        System.out.println("Wycztany napis:");
        for (String wiersz : wiersze)
        {
            System.out.println(wiersz);
        }
        System.out.println("\nZaszyfrowany napis:");
        for (String wiersz : zaszyfrowany)
        {
            System.out.println(wiersz);
            writer.write(wiersz.toString());
            writer.newLine();
        }
        writer.close();
        System.out.println("\nOdszyfrowany napis:");
        for (String wiersz : odszyfrowany)
        {
            System.out.println(wiersz);
        }
        System.out.println("\nCzy palindrom:");
        for (int i = 0;i<wiersze.size();i++)
        {
            if(palindrom.get(i) == true) System.out.println(wiersze.get(i) + "  :  Jest palindromem");
            else System.out.println(wiersze.get(i) + "  :  Nie jest palindromem");
        }
    }

    public static String wczytajDane() {
        System.out.println("Podaj napis: ");
        Scanner scanner = new Scanner(System.in);
        String napis = scanner.nextLine();
        return napis;
    }

    private static String szyfruj(String wczytanyNapis, int przesuniecie) {
        StringBuilder zaszyfrowane = new StringBuilder();
        for (char znak : wczytanyNapis.toCharArray()) {
            if (znak >= 'a' && znak <= 'z') {                                 //alfabet małych liter
                int pozycjaZnaku = znak - 'a';                                 //Potrzebujemy pozycji zgodnie z alfabetem np. z kodu ASCII a = 97 będzie wskazywać na pierwszą pozycję
                int nowaPozycja = (pozycjaZnaku + przesuniecie) % ROZMIAR_ALFABETU; // o ile pozycji przesuwamy. Modulo jest po to, aby nie przekroczyć alfabetu.
                char zaszyfrowanyZnak = (char) ('a' + nowaPozycja);   // ile od a (pozycji pierwszej) ma być przesunięcie do nowej pozycji
                zaszyfrowane.append(zaszyfrowanyZnak);
            } else if (znak >= 'A' && znak <= 'Z') {                  //to samo dla dużych liter alfabetu
                int pozycjaZnaku = znak - 'A';
                int nowaPozycja = (pozycjaZnaku + przesuniecie) % ROZMIAR_ALFABETU;
                char zaszyfrowanyZnak = (char) ('A' + nowaPozycja);
                zaszyfrowane.append(zaszyfrowanyZnak);
            } else {
                zaszyfrowane.append(znak);
            }
        }
        return zaszyfrowane.toString();
    }

    private static String odszyfruj(String zaszyfrowanyNapis, int przesuniecie) {
        // return szyfruj(zaszyfrowanyNapis, ROZMIAR_ALFABETU-(przesuniecie%ROZMIAR_ALFABETU));     //zadziała tylko dla małych znaków
        StringBuilder odszyfrowane = new StringBuilder();
        for (char znak : zaszyfrowanyNapis.toCharArray()) {
            if (znak >= 'a' && znak <= 'z') {
                int pozycjaZnaku = znak - 'a';
                int nowaPozycja = (pozycjaZnaku - przesuniecie + ROZMIAR_ALFABETU) % ROZMIAR_ALFABETU;
                char odszyfrowanyZnak = (char) ('a' + nowaPozycja);
                odszyfrowane.append(odszyfrowanyZnak);
            } else if (znak >= 'A' && znak <= 'Z') {
                int pozycjaZnaku = znak - 'A';
                int nowaPozycja = (pozycjaZnaku - przesuniecie + ROZMIAR_ALFABETU) % ROZMIAR_ALFABETU; // o ile pozycji przesuwamy, modulo jest po to, aby nie przekroczyć alfabetu, plus rozmiar aby nie wyjść poza alfabet czyli znaków specjalnych
                char odszyfrowanyZnak = (char) (nowaPozycja + 'A');
                odszyfrowane.append(odszyfrowanyZnak);
            } else {
                odszyfrowane.append(znak);
            }
        }
        return odszyfrowane.toString();
    }

    private static Boolean czyJestPalindromem(String napis) {
        String napisBezSpacji = napis.toLowerCase().replaceAll(" ", "");
        String odwroconyNapis = "";
        for (int i = napisBezSpacji.length(); i > 0; i--) {
            char znak = napisBezSpacji.charAt(i - 1);
            odwroconyNapis += znak;
        }
        //System.out.println("Napis bez spacji: " + napisBezSpacji);
        //System.out.println("Odwrócony napis: " + odwroconyNapis);
        return napisBezSpacji.equals(odwroconyNapis);
    }
}
