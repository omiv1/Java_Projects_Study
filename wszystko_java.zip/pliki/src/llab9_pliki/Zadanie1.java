package llab9_pliki;

import java.io.*;
import java.util.Date;

public class Zadanie1 {
    public static void main(String[] args) throws IOException {

        File plik = new File("C:\\Users\\lukas\\IdeaProjects\\pliki\\lotto.txt");
        if (plik.isDirectory() == false) System.out.println("jest plikiem1");
        if (plik.isFile()) System.out.println("jest plikiem2");
        Date data = new Date(plik.lastModified());
        System.out.println(data);
        //FileReader fileReader = new FileReader()
        String linia = "";
        BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\lukas\\IdeaProjects\\pliki\\lotto.txt"));
        while (linia != null)
        {
            linia = br.readLine();
            //System.out.println(linia);
            if (linia != null) podziel(linia);
        }
        br.close();
    }
    public static void podziel(String linia)
    {
        String tab[] = linia.split(" ");
        String tab2[] = tab[2].split(",");
        //for () {

        }
    }
}
