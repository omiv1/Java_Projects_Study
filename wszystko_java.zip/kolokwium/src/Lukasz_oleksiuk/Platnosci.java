package Lukasz_oleksiuk;

public interface Platnosci {
    default double podlicz()
    {
        double wynik = 0;
        return wynik;
    }
    default void wystaw_paragon()
    {

    }
}
