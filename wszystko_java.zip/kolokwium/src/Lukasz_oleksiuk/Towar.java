package Lukasz_oleksiuk;

public abstract class Towar
{
    private double cena=0;

    public Towar()
    {

    }

    public Towar(double cena) {
        if (cena <= 0) throw new IllegalArgumentException("Niewlasciwy parametr");
        this.cena = cena;
    }

    protected abstract String get_type();

    public double getCena() {
        return cena;
    }

    public void setCena(double cena) {

            if (cena <= 0) throw new IllegalArgumentException("Niewlasciwy parametr");
            this.cena = cena;
    }

    @Override
    public String toString() {
        return "Towar{" +
                "cena=" + cena +
                '}';
    }
}
