package Lukasz_oleksiuk;

public class Granat extends Towar
{
    public Granat(double cena) {
        super(cena);
    }

    @Override
    protected String get_type() {
        return "Granat";
    }

    @Override
    public String toString() {
        return "Granat{}";
    }
}
