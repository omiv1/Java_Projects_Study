package Lukasz_oleksiuk;

public class Avocado extends Towar
{
    public Avocado(double cena) {
        super(cena);
    }

    @Override
    protected String get_type() {
        return "Avocado";
    }
}
