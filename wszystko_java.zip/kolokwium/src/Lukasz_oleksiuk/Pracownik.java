package Lukasz_oleksiuk;

public class Pracownik implements Platnosci
{
    private String imie;
    private String nazwisko;
    private double stawka_za_godzine;
    private int przepracowane_godzny;

    public Pracownik(String imie, String nazwisko, double stawka_za_godzine, int przepracowane_godzny) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        if (stawka_za_godzine <= 0) throw new IllegalArgumentException("Niewlasciwy parametr");
        this.stawka_za_godzine = stawka_za_godzine;
        if (przepracowane_godzny < 0) throw new IllegalArgumentException("Niewlasciwy parametr");
        this.przepracowane_godzny = przepracowane_godzny;
    }
    public Pracownik() {

    }
    public void wystaw_paragon()
    {
        System.out.println(imie + " " + nazwisko + " " + " stawka: " + stawka_za_godzine + ", godziny: " + przepracowane_godzny + ", zarobil: " + stawka_za_godzine*przepracowane_godzny + " zl");
    }

    public String getImie() {
        return imie;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }

    public double getStawka_za_godzine() {
        return stawka_za_godzine;
    }

    public void setStawka_za_godzine(double stawka_za_godzine) {
        if (stawka_za_godzine <= 0) throw new IllegalArgumentException("Niewlasciwy parametr");
        this.stawka_za_godzine = stawka_za_godzine;
    }

    public int getPrzepracowane_godzny() {
        return przepracowane_godzny;
    }

    public void setPrzepracowane_godzny(int przepracowane_godzny) {
        if (przepracowane_godzny < 0) throw new IllegalArgumentException("Niewlasciwy parametr");
        this.przepracowane_godzny = przepracowane_godzny;
    }

    @Override
    public String toString() {
        return "Pracownik{" +
                "imie='" + imie + '\'' +
                ", nazwisko='" + nazwisko + '\'' +
                ", stawka_za_godzine=" + stawka_za_godzine +
                ", przepracowane_godzny=" + przepracowane_godzny +
                '}';
    }
}
