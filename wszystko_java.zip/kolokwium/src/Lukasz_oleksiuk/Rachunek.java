package Lukasz_oleksiuk;

import java.util.Arrays;

public class Rachunek implements Platnosci
{
    private Towar tablica[];

    public Rachunek(Towar[] tablica) {
        this.tablica = tablica;
    }

    public Towar[] getTablica() {
        return tablica;
    }

    public void setTablica(Towar[] tablica) {
        this.tablica = tablica;
    }
    public void wystaw_paragon()
    {
        double suma=0;
        for(int i=0;i<tablica.length;i++)
        {
            System.out.println(tablica[i].get_type() + " " + "cena: " + tablica[i].getCena());
            suma = suma + tablica[i].getCena();
        }
        System.out.println("--------------");
        System.out.println("Suma: " + suma + " zl");
        System.out.println(("Srednia: " + suma/tablica.length) + " zl");
        System.out.println("Srednia^2: " + (suma/tablica.length)*(suma/tablica.length) + " zl");
    }

    @Override
    public String toString() {
        return "Rachunek{" +
                "tablica=" + Arrays.toString(tablica) +
                '}';
    }
}
