package pl.patrycja.miazek.lab3;

import java.util.Scanner;

public class BinarnaZerowka {

  public static void main(String[] args) {
    int wczytaj = wczytajDane();
    System.out.println(wczytaj);
    String bin = konwertujNaBin(wczytaj);
    System.out.println(bin);
    System.out.println(ileSekwencjiZer("000101100"));
  }

  public static int wczytajDane() {
    int liczba;
    System.out.println("Podaj liczba: ");
    Scanner scanner = new Scanner(System.in);
    liczba = scanner.nextInt();
    return liczba;

  }

  public static String konwertujNaBin(int liczba) {
    StringBuilder stringBuilder = new StringBuilder();
    for (int i = liczba; i != 0; i = i / 2) {
      stringBuilder.append(i % 2);
    }

    stringBuilder.reverse();
    System.out.println(stringBuilder.toString());
    return stringBuilder.toString();

    //   return Integer.toBinaryString(liczba);     //Ten sam wynik możemy zwrócić za pomocą metody toBinaryString();
  }


  public static int ileSekwencjiZer(String liczba) {
    boolean znalazloJedynke = false;
      int ileZer = 0;
      int licznikSekwencji =0;

    for (char znak : liczba.toCharArray()) {
      if (znak == '1' && znalazloJedynke == false) {
        znalazloJedynke = true;
      } else if ( znak == '1' && znalazloJedynke ==true && ileZer >0) {
        licznikSekwencji ++;
        ileZer = 0;
      } else if (znak == '0' && znalazloJedynke == true) {
          ileZer ++;
      }

    }
    return licznikSekwencji;
  }
}

