package pl.patrycja.miazek.lab3;

import java.util.Scanner;

public class Main {

  public static void main(String[] args) {

ASCII.ascii("a");
  }
}