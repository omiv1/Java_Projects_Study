package pl.patrycja.miazek.lab3;

public class IleLiter {

  //zadanie 3.1

  public static void main(String[] args) {
    System.out.println(count("Ala ma kota", 'a'));
  }

  public static int count(String napis, char litera) {
    int ileLiter = 0;

    for (int i = 0; i < napis.length(); i++) {
      // sprawdzanie znaku w ciągu
      if (napis.charAt(i) == litera) {        //charAt zwraca znak o określonym indeksie ciągu
        ileLiter++;
      }
    }
    return ileLiter;
  }
}
