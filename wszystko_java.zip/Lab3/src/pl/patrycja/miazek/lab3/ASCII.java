package pl.patrycja.miazek.lab3;

public class ASCII {

  public static void main(String[] args) {
    ASCII.ascii("a");
  }

  // zadanie 3.2
  public static int ascii(String napis) {
    int suma = 0;
    for (char znak : napis.toCharArray()) {         //idziemy po  każdym  znaku (char), toCharArray() konwertuje podany ciąg na sekwencję znaków
      if (znak >= 'a' && znak <= 'z' || znak >= '0' && znak <= '9') {
        suma += znak;
      }
    }
    System.out.println(suma);
    return suma;
  }
}
