package pl.patrycja.miazek.lab3;

import java.util.Scanner;


// zadanie 3.3
public class LiczbaNaZnak {

  public static void main(String[] args) {
    int liczba = wczytajDane();
    System.out.println(liczba);
    char liczbaNaZnakWynik = liczbaNaZnak(liczba);
    System.out.println("Wynik: " + liczbaNaZnakWynik);
  }

  public static int wczytajDane() {
    int liczba;
    do {
      System.out.println("Podaj liczbę: ");
      Scanner scanner = new Scanner(System.in);
      liczba = scanner.nextInt();
    } while (liczba < 33 || liczba > 126);
    return liczba;
  }

  public static char liczbaNaZnak(int liczba) {
    return (char) liczba;
  }


}
