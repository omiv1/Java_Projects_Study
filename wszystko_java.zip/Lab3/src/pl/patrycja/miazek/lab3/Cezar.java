package pl.patrycja.miazek.lab3;

import java.util.Locale;
import java.util.Scanner;

public class Cezar {

  private static final int ROZMIAR_ALFABETU = 'z' - 'a' + 1;
  private static final int PRZESUNIECIE = 3;

  public static void main(String[] args) {
    String wczytaj = wczytajDane();
    String zaszyfrowanyCiagZnakow = szyfruj(wczytaj, PRZESUNIECIE);
    System.out.println("Zaszyfrowany ciąg znaków: " + zaszyfrowanyCiagZnakow);
    String odszyfrowanyCiagZnakow = odszyfruj(zaszyfrowanyCiagZnakow, PRZESUNIECIE);
    System.out.println("Odszyfrowany ciąg znaków: " + odszyfrowanyCiagZnakow);
    Boolean palindrom = czyJestPalindromem(wczytaj);
    System.out.println("Czy jest palindromem: " + palindrom);
  }

  public static String wczytajDane() {
    System.out.println("Podaj napis: ");
    Scanner scanner = new Scanner(System.in);
    String napis = scanner.nextLine();
    return napis;
  }

  private static String szyfruj(String wczytanyNapis, int przesuniecie) {
    StringBuilder zaszyfrowane = new StringBuilder();
    for (char znak : wczytanyNapis.toCharArray()) {
      if (znak >= 'a' && znak <= 'z') {                                 //alfabet małych liter
        int pozycjaZnaku = znak - 'a';                                 //Potrzebujemy pozycji zgodnie z alfabetem np. z kodu ASCII a = 97 będzie wskazywać na pierwszą pozycję
        int nowaPozycja = (pozycjaZnaku + przesuniecie) % ROZMIAR_ALFABETU; // o ile pozycji przesuwamy. Modulo jest po to, aby nie przekroczyć alfabetu.
        char zaszyfrowanyZnak = (char) ('a' + nowaPozycja);   // ile od a (pozycji pierwszej) ma być przesunięcie do nowej pozycji
        zaszyfrowane.append(zaszyfrowanyZnak);
      } else if (znak >= 'A' && znak <= 'Z') {                  //to samo dla dużych liter alfabetu
        int pozycjaZnaku = znak - 'A';
        int nowaPozycja = (pozycjaZnaku + przesuniecie) % ROZMIAR_ALFABETU;
        char zaszyfrowanyZnak = (char) ('A' + nowaPozycja);
        zaszyfrowane.append(zaszyfrowanyZnak);
      } else {
        zaszyfrowane.append(znak);
      }
    }
    return zaszyfrowane.toString();
  }

  private static String odszyfruj(String zaszyfrowanyNapis, int przesuniecie) {
    // return szyfruj(zaszyfrowanyNapis, ROZMIAR_ALFABETU-(przesuniecie%ROZMIAR_ALFABETU));     //zadziała tylko dla małych znaków
    StringBuilder odszyfrowane = new StringBuilder();
    for (char znak : zaszyfrowanyNapis.toCharArray()) {
      if (znak >= 'a' && znak <= 'z') {
        int pozycjaZnaku = znak - 'a';
        int nowaPozycja = (pozycjaZnaku - przesuniecie + ROZMIAR_ALFABETU) % ROZMIAR_ALFABETU;
        char odszyfrowanyZnak = (char) ('a' + nowaPozycja);
        odszyfrowane.append(odszyfrowanyZnak);
      } else if (znak >= 'A' && znak <= 'Z') {
        int pozycjaZnaku = znak - 'A';
        int nowaPozycja = (pozycjaZnaku - przesuniecie + ROZMIAR_ALFABETU) % ROZMIAR_ALFABETU; // o ile pozycji przesuwamy, modulo jest po to, aby nie przekroczyć alfabetu, plus rozmiar aby nie wyjść poza alfabet czyli znaków specjalnych
        char odszyfrowanyZnak = (char) (nowaPozycja + 'A');
        odszyfrowane.append(odszyfrowanyZnak);
      } else {
        odszyfrowane.append(znak);
      }
    }
    return odszyfrowane.toString();
  }

  private static Boolean czyJestPalindromem(String napis) {
    String napisBezSpacji = napis.toLowerCase().replaceAll(" ", "");
    String odwroconyNapis = "";
    for (int i = napisBezSpacji.length(); i > 0; i--) {
      char znak = napisBezSpacji.charAt(i - 1);
      odwroconyNapis += znak;
    }
    System.out.println("Napis bez spacji: " + napisBezSpacji);
    System.out.println("Odwrócony napis: " + odwroconyNapis);
    return napisBezSpacji.equals(odwroconyNapis);
  }
}
