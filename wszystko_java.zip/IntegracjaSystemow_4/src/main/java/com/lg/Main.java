package com.lg;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main
{
    public static void main(String[] args) {
        System.out.println("JPA preject!");
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("Hibernate_JPA");
    }


}
