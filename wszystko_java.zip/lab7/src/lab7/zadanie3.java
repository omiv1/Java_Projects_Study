package lab7;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.Scanner;

import java.util.ArrayList;

public class zadanie3 {
    public static void wypisz()
    {
        Scanner scanner = new Scanner(System.in);
        LinkedList<Integer> liczby = new LinkedList<>();
        int liczba = 1;
        int suma = 0;
        int iloczyn = 1;
        do
        {
            System.out.println("podaj liczbe:");
            liczba = scanner.nextInt();
            if (liczba != 0) liczby.add(liczba);
            suma = suma + liczby.getLast();
            iloczyn = iloczyn * liczby.getLast();
        }while (Math.abs(suma) < 250 && Math.abs(iloczyn) < 3000000);
        liczby.sort(Comparator.reverseOrder());
        System.out.println(liczby);

    }
}