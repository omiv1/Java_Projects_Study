package lab7;
import java.util.LinkedList;
import java.util.Scanner;

import java.util.ArrayList;

public class zadanie2 {
    public static void wypisz()
    {
        Scanner scanner = new Scanner(System.in);
        LinkedList<Integer> liczby = new LinkedList<>();
        int liczba = 1;
        do
        {
            System.out.println("podaj liczbe:");
            liczba = scanner.nextInt();
            if (liczba != 0) liczby.add(liczba);
        }while (liczba != 0);
        int suma = 0;
        int iloczyn = 1;
        for(int i=0;i<liczby.size();i++)
        {
            suma = suma + liczby.get(i);
            iloczyn = iloczyn * liczby.get(i);
        }
        System.out.println("suma = " + suma);
        System.out.println("iloczyn = " + iloczyn);
        System.out.println("rozmiar = " + liczby.size());

    }
}
