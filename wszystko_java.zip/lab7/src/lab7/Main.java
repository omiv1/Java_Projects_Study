package lab7;

import java.util.Arrays;

public class Main {
    public static void main(String[] args)
    {
        //zadanie2.wypisz();
        zadanie3.wypisz();

    }
}