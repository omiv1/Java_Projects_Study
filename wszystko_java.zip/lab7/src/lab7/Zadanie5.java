package lab7;
import java.util.LinkedList;
import java.util.Scanner;

import java.util.ArrayList;

public class Zadanie5 {
    public static void wypisz()
    {
        Scanner scanner = new Scanner(System.in);
        LinkedList<Integer> liczby = new LinkedList<>();
        int liczba = 1;
        do
        {
            System.out.println("podaj liczbe:");
            liczba = scanner.nextInt();
            if (liczba != 0) liczby.add(liczba);
        }while (liczba != 0);

    }
}