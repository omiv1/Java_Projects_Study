package lab5_lukasz_oleksiuk;

import java.awt.*;

import static java.lang.Math.sqrt;

public class Elipsa extends Figura{
    private int a,b,F1x,F1y,F2x,F2y;

    public Elipsa(int pole, int obwod, Color kolor, int a, int b, int f1x, int f1y, int f2x, int f2y) {
        super(pole, obwod, kolor);
        this.a = a;
        this.b = b;
        F1x = f1x;
        F1y = f1y;
        F2x = f2x;
        F2y = f2y;
    }

    public double ognisko_do_srodka(int a,int b)
    {
        double c;
        c = (a*a)-(b*b);
        c = sqrt(c);
        return c;
    }
    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    public int getF1x() {
        return F1x;
    }

    public void setF1x(int f1x) {
        F1x = f1x;
    }

    public int getF1y() {
        return F1y;
    }

    public void setF1y(int f1y) {
        F1y = f1y;
    }

    public int getF2x() {
        return F2x;
    }

    public void setF2x(int f2x) {
        F2x = f2x;
    }

    public int getF2y() {
        return F2y;
    }

    public void setF2y(int f2y) {
        F2y = f2y;
    }
}
