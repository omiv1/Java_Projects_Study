package lab5_lukasz_oleksiuk;

import java.awt.*;

public class Main {
    public static void main(String[] args)
    {
        Elipsa e1 = new Elipsa(10,20, Color.red,5,3,5,3,6,7);
        Wielokat w1 = new Wielokat(10,20,Color.blue,5,5,150);
        w1.setSuma_katow(140);
    }
}