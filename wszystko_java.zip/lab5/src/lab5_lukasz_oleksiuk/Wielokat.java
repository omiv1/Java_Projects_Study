package lab5_lukasz_oleksiuk;

import java.awt.*;

public class Wielokat extends Figura{
    private int liczba_wierzcholkow,liczba_bokow,suma_katow;

    public Wielokat(int pole, int obwod, Color kolor, int liczba_wierzcholkow, int liczba_bokow, int suma_katow) {
        super(pole, obwod, kolor);
        this.liczba_wierzcholkow = liczba_wierzcholkow;
        this.liczba_bokow = liczba_bokow;
        this.suma_katow = suma_katow;
    }
    public void suma_katow()
    {
        suma_katow = (liczba_bokow-2)*180;
    }

    public int getLiczba_wierzcholkow() {
        return liczba_wierzcholkow;
    }

    public void setLiczba_wierzcholkow(int liczba_wierzcholkow) {
        this.liczba_wierzcholkow = liczba_wierzcholkow;
    }

    public int getLiczba_bokow() {
        return liczba_bokow;
    }

    public void setLiczba_bokow(int liczba_bokow) {
        this.liczba_bokow = liczba_bokow;
    }

    public int getSuma_katow() {
        return suma_katow;
    }

    public void setSuma_katow(int suma_katow) {
        this.suma_katow = suma_katow;
    }
}
