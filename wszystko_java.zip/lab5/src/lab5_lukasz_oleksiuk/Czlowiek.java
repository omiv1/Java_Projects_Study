package lab5_lukasz_oleksiuk;

public abstract class Czlowiek {
    public void jedz()
    {

    }
    public void pij()
    {

    }
    public void ile_lat()
    {

    }
    public void cechy()
    {

    }
}
