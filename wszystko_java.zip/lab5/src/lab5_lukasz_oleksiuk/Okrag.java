package lab5_lukasz_oleksiuk;

import java.awt.*;

public class Okrag extends Elipsa{

    public Okrag(int pole, int obwod, Color kolor, int a, int b, int f1x, int f1y, int f2x, int f2y) {
        super(pole, obwod, kolor, a, b, f1x, f1y, f2x, f2y);
    }
}
