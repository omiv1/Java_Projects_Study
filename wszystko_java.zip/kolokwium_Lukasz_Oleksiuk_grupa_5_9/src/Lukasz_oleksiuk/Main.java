package Lukasz_oleksiuk;

public class Main {
    public static void main(String[] args)
    {
        Pracownik p[] = new Pracownik[3];
        for(int i=0;i<3;i++)
        {
            p[i] = new Pracownik("jan","kowalski",30+i,60-i);
            p[i].wystaw_paragon();
        }
        //p[0].setPrzepracowane_godzny(-2);
        //p[0].setStawka_za_godzine(-5);
        //Pracownik test = new Pracownik("jan","kowalski",-4,-1);
        System.out.println();

        int rozmiar = 3;
        Towar t[] = new Towar[rozmiar];
        t[0] = new Avocado(6);
        t[1] = new Avocado(6);
        t[2] = new Granat(9);
        for(int i=0;i<rozmiar;i++)
        {
            System.out.println(t[i].get_type() + "cena: " + t[i].getCena() + " zl");
        }
        System.out.println();
        Rachunek r = new Rachunek(t);
        r.wystaw_paragon();

        //Towar test2 = new Granat(-5);
        //t[0].setCena(-8);


    }
}