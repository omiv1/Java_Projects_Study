package Lukasz_oleksiuk;

public interface Platnosci {
     double podlicz();
     void wystaw_paragon();

}
