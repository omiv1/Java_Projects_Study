public class Zadanie2klient extends Thread
{
    private Zadanie2sklep sklep;
    private int liczba;

    public Zadanie2klient(Zadanie2sklep sklep, int liczba) {
        this.sklep = sklep;
        this.liczba = liczba;
    }
    public void run()
    {
        int value = 0;
        for(int i=0;i<10;i++)
        {
            value = sklep.getBulki();
            System.out.println("wartosc: " + liczba + " ma: " + value);
        }
    }
}
