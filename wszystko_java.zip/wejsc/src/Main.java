import java.util.*;

class SortowanieGor
{
    LinkedList<Gora> mtn = new LinkedList<Gora>();
    public void doDziela()
    {
        mtn.add(new Gora("Kasprowy", 1987));
        mtn.add(new Gora("Koscielna", 2155));
        mtn.add(new Gora("Swianica", 2301));
        mtn.add(new Gora("Rysy", 2499));
        System.out.println("Bez sortowania: \n"+mtn);
        NazwaCompare nc = new NazwaCompare();
        System.out.println("Wg nazway: \n"+mtn);
        WysokoscCompare wc = new WysokoscCompare();
        System.out.println("Wg wysokosci: \n"+mtn);

    }
    class NazwaCompare implements Comparator<Gora>
    {
        public int compare(Gora g1, Gora g2)
        {
            return g1.nazwa.compareTo(g2.nazwa);
        }
    }
    class WysokoscCompare implements Comparator<Gora>
    {
        public int compare(Gora g1,Gora g2)
        {
            return g2.wysokosc - g1.wysokosc;
        }
    }

    public static void main(String[] args) {
        new SortowanieGor().doDziela();
    }
}

class Gora
{
    public String nazwa;
    public int wysokosc;
    public Gora(String nazwa, int wysokosc)
    {
        this.nazwa = nazwa;
        this.wysokosc = wysokosc;
    }
}