import java.util.Random;

public class zadanie1 implements Runnable
{
    private long timestamp;

    public zadanie1(long timestamp)
    {
        this.timestamp = timestamp;
    }

    @Override
    public void run() {
        Random random = new Random(timestamp);
        System.out.println("wylosowana liczba: " + random.nextInt(0,101));
    }
}
