public class Zadanie2produkty extends Thread
{
    private Zadanie2sklep sklep;
    private int liczba;

    public Zadanie2produkty(Zadanie2sklep sklep, int liczba) {
        this.sklep = sklep;
        this.liczba = liczba;
    }
    public void run()
    {
        for(int i=0;i<10;i++)
        {
            sklep.put(i);
            System.out.println("liczba: " + liczba + " put: " + i);
            try {
                sleep((int)(Math.random()*100));
            }
            catch (InterruptedException ie)
            {
                ie.printStackTrace();
            }
        }
    }
}
