
public class zadanie1main {
    public static void main(String[] args) {
        /*long timestamp = System.currentTimeMillis();
        for(int i = 0;i<50;i++)
        {
            zadanie1 z1 = new zadanie1(timestamp);
            z1.run();

        }*/
        Zadanie2sklep sklep = new Zadanie2sklep();
        Zadanie2klient klient = new Zadanie2klient(sklep, 1);
        Zadanie2produkty produkty  = new Zadanie2produkty(sklep, 1);
        produkty.start();
        klient.start();
    }
}
