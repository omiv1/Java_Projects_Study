public class Zadanie2sklep {
    private int bulki;
    private boolean dostepnosc = false;

    public synchronized int getBulki()
    {
        while (dostepnosc == false)
        {
            try {
                wait();
            }
            catch (InterruptedException ie)
            {
                ie.printStackTrace();
            }
        }
        dostepnosc = false;
        notifyAll();
        return bulki;
    }
    public synchronized void put(int wartosc)
    {
        while (dostepnosc == true)
        {
            try {
                wait();
            }
            catch (InterruptedException ie)
            {
                ie.printStackTrace();
            }
        }
        dostepnosc = true;
        notifyAll();
        bulki = wartosc;
    }
}
