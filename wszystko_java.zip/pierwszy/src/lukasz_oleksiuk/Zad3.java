package lukasz_oleksiuk;

public class Zad3 {
    static char tochar(int liczba)
    {
        return (char)liczba;
    }
}
