package lukasz_oleksiuk;

import java.util.Scanner;

public class Zadanie4 {
    private  static  final int ROZMIARALFABETU= 'z'-'a'+1;
    private  static  final int PRZESUNIECIE = 3;

    public  static  void main(String[] args)
    {
        String wczytaj;
    }
   static String wczytajdane()
   {
       System.out.println("podaj dane: ");
       Scanner scanner = new Scanner(System.in);
       String napis = scanner.nextLine();
       return napis;
   }
   static String zaszyfruj(String wczytanenapis, int przesuniecie)
   {
       StringBuilder zaszyfrowany = new StringBuilder();
       for(char znak:wczytanenapis.toCharArray())
       {
           if(znak>= 'a' && znak <= 'z')
           {
               int pozycja = znak - 'a';
               int nowapozycja = (pozycja+przesuniecie)%ROZMIARALFABETU;
               char zaszyfrowanyznak = (char)('a'+nowapozycja);
               zaszyfrowany.append(zaszyfrowanyznak);
           } else if (znak>= 'A' && znak <= 'Z')
           {
               int pozycja = znak - 'A';
               int nowapozycja = (pozycja+przesuniecie)%ROZMIARALFABETU;
               char zaszyfrowanyznak = (char)('A'+nowapozycja);
               zaszyfrowany.append(zaszyfrowanyznak);
           }
           else
           {
               zaszyfrowany.append(znak);
           }
       }
       return zaszyfrowany.toString();
   }
}
