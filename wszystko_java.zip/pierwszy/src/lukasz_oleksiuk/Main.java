package lukasz_oleksiuk;

public class Main {
    public static void main(String[] args)
    {
        System.out.println(zadanie1.ileznakow('a',"ala ma kota"));
        System.out.println(Zad3.tochar(97));
    }
}