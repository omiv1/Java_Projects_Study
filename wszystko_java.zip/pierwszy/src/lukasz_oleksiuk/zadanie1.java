package lukasz_oleksiuk;

public class zadanie1 {
    static int ileznakow(char znak,String ciagznakow)
    {
        int licznik=0;
        for (int i=0;i<ciagznakow.length();i++)
        {
            if(ciagznakow.charAt(i) == znak) licznik++;
        }
        return licznik;
    }
}
