package com.lg;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

//import javax.persistence.EntityManager;
//import javax.persistence.EntityManagerFactory;
//import javax.persistence.Persistence;
//import javax.persistence.Query;
//import javax.persistence.TypedQuery;

public class Main
{
    public static void main(String[] args) {
        System.out.println("JPA preject!");
        //EntityManagerFactory factory = Persistence.createEntityManagerFactory("Hibernate_JPA");
    }


}
