package kolos2;

import java.util.Random;

public class Womtek implements Runnable{
    public long[] liczby;

    public Womtek(long[] liczby) {
        this.liczby = liczby;
    }

    public long[] getLiczby() {
        return liczby;
    }

    public void setLiczby(long[] liczby) {
        this.liczby = liczby;
    }

    @Override
    public void run()
    {
        for(long l : liczby)
        {
            Random random = new Random(System.currentTimeMillis());
            l = random.nextInt();
            System.out.println(l);
        }

    }
}
