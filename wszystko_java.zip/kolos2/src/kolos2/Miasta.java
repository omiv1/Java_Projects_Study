package kolos2;

public class Miasta {
    public String nazwa;
    public int liczba;

    public Miasta(String nazwa) {
        this.nazwa = nazwa;
        liczba=1;
    }

    public String getNazwa() {
        return nazwa;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public int getLiczba() {
        return liczba;
    }

    public void setLiczba(int liczba) {
        this.liczba = liczba;
    }
    public void dodaj()
    {
        liczba++;
    }
    public  void show()
    {
        System.out.println(nazwa+ " " + liczba);
    }
}
