package kolos2;

import java.util.Comparator;

public class Klient extends Czlowiek
{
    public String miasto;
    public String data;
    public int vin;
    public int koszt;

    public Klient(String imie, String nazwisko) {
        super(imie, nazwisko);
    }

    public Klient(String imie, String nazwisko, String miasto, String data,int koszt, int vin)
    {
        super(imie,nazwisko);
        this.miasto = miasto;
        this.data = data;
        this.koszt = koszt;
        this.vin = vin;
    }
    public void show()
    {
        System.out.println(imie+" "+nazwisko+" "+miasto+" "+data+" "+koszt+" "+vin);
    }

    public String getMiasto() {
        return miasto;
    }

    public void setMiasto(String miasto) {
        this.miasto = miasto;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public int getVin() {
        return vin;
    }

    public void setVin(int vin) {
        this.vin = vin;
    }

    public int getKoszt() {
        return koszt;
    }

    public void setKoszt(int koszt) {
        this.koszt = koszt;
    }

    public static Comparator<Klient> imie_c = new Comparator<Klient>()
    {
        public int compare(Klient s1, Klient s2)
        {
            String StudentName1 = s1.getImie().toUpperCase();
            String StudentName2 = s2.getImie().toUpperCase();
            return StudentName1.compareTo(StudentName2);
        }
    };
}
