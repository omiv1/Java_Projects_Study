package kolos2;

import java.io.*;
import java.util.*;

import static java.util.Collections.*;

public class Main {
    public static void main(String[] args) throws IOException {
        Klient k1 = new Klient("jan","kowla","lublin","2020-10-03",100,1);
        k1.show();
        File plik = new File("C:\\Users\\lukas\\IdeaProjects\\kolos2\\src\\kolos2\\auto.txt");
        File zapis = new File("wynik.txt");

        Scanner in = new Scanner(plik);
        BufferedWriter out = new BufferedWriter(new FileWriter(zapis));

        String podzial[];

        Klient k[] = new Klient[500];
        for(int i=0;i<500;i++)
        {
            String linia = in.nextLine();
            podzial = linia.split(";");
            //System.out.println(podzial[0] +" "+podzial[1]+" "+podzial[2]+" "+podzial[3]+" "+podzial[4]);
            k[i] = new Klient(podzial[0],podzial[1],podzial[2],podzial[3],Integer.parseInt(podzial[4]),Integer.parseInt(podzial[5]));
            if(podzial[3].substring(8,10).equals("05")) {
                //k[i].show();
            }
        }
        ArrayList<Klient> klients = new ArrayList<Klient>();
        for(int i=0;i<500;i++)
        {
            klients.add(k[i]);
        }
        //Collections.sort(klients,Klient.imie_c);
        //klients.sort(Comparator.comparing(Klient::getImie));
        klients.sort(Comparator.comparing(Klient::getImie).reversed().thenComparing(Klient::getNazwisko));
        for(int i=0;i<500;i++)
        {
            if (klients.get(i).getData().substring(8,10).equals("05"));
                //System.out.println();
                //klients.get(i).show();
        }
        ArrayList<Miasta> miasta = new ArrayList<Miasta>();
        System.out.println(miasta.size());
        //miasta.add(new Miasta(k[0].getMiasto()));
        int pom=0;
        for(int i=0;i<500;i++)
        {
            for (int j = 0; j < miasta.size(); j++) {
                if (miasta.get(j).getNazwa().equals(k[i].getMiasto())) {
                    miasta.get(j).dodaj();
                    pom=1;
                }
            }
            if(pom==0)
            {
                miasta.add(new Miasta(k[i].getMiasto()));
            }
        }
        miasta.sort(Comparator.comparing(Miasta::getLiczba).reversed());
        System.out.println(miasta.size());
        for(int i=0;i<5;i++)
        {
            miasta.get(i).show();
        }

        for(int i=0;i<500;i++)
        {
            if(klients.get(i).getKoszt() > 350)
            {
                out.write(klients.get(i).getKoszt()+" "+klients.get(i).getMiasto()+"\n");
            }
        }
        out.close();

        HashSet<String> sam = new HashSet<String>();
        HashSet<String> sam2 = new HashSet<String>();
        int pom2=0;
        int pom3=0;
        for(int i=0;i<500;i++)
        {
            pom2=sam.size();
            sam.add(klients.get(i).getMiasto());
            if(pom2==sam.size())
            {
                sam2.add(klients.get(i).getMiasto());

                //System.out.println(klients.get(i).getMiasto());
            }
        }
        for(String kl : sam2)
        {
            //System.out.println(kl);
            pom3++;
        }
        System.out.println(pom3);

        ArrayList<Klient> arr = new ArrayList<Klient>();
        for(int i=0;i<500;i++)
        {
            arr.add(k[i]);
        }
        arr.sort(Comparator.comparing(Klient::getImie).thenComparing(Klient::getNazwisko));
        for(int i=0;i<500;i++)
        {
            //    arr.get(i).show();
        }
        Vector<Klient> vec = new Vector<Klient>();
        for(int i=0;i<500;i++)
        {
            vec.add(k[i]);
        }
        vec.sort(Comparator.comparing(Klient::getImie).thenComparing(Klient::getNazwisko));
        for(int i=0;i<500;i++)
        {
                //vec.get(i).show();
        }

        long tab[] = new long[20];
        Womtek w1 = new Womtek(tab);
        w1.run();

        Womtek2 w2 = new Womtek2(w1.getLiczby());
        w2.run();
        /*for(Klient kl : klients)
        {
            kl.show();
        }*/
    }
}