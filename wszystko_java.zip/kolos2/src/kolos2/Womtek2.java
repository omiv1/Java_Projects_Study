package kolos2;

public class Womtek2 implements Runnable{
    public long[] liczby;

    public Womtek2(long[] liczby) {
        this.liczby = liczby;
    }

    @Override
    public void run()
    {
        for(long l : liczby)
        {
            System.out.println(l);
        }

    }
}
