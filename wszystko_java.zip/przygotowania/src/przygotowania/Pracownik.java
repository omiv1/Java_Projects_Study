package przygotowania;

public class Pracownik
{
    private int wiek;

    public Pracownik(int wiek) {
        this.wiek = wiek;
    }
    public void wypisz()
    {
        System.out.println("metoda pracownik");
    }
}
