package przygotowania;

public interface Inter {
    int t = 0;

}
