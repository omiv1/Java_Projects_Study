package przygotowania;

import java.util.Scanner;

public class Trojkat extends Abstrakcyjna
{
        private int i=-1;

    public Trojkat(int rozmiar) {
        super(rozmiar);
        //this.i = i;
    }
    public  void pobierz()
    {
        Scanner scanner = new Scanner(System.in);
        boolean blad = true;
       do
        {
            try
            {
                i = Integer.parseInt(scanner.nextLine());
                blad=false;
            }
            catch (NumberFormatException n)
            {
                System.out.println("podaj odpiewiednia wartosc");
            }
            //if (i!=-1) blad = false;
        } while (blad==true);
    }
    public void pokarz()
    {
        System.out.println(i);
    }

}
