package przygotowania;

public class Main {
    public static void main(String[] args) {
        System.out.println("hello");

        //Teksty.wczytaj();
        //Teksty.wyswietl();
        //Teksty.przesun();
        //Teksty.each();
        //Trojkat t = new Trojkat();
        //t.pobranie();
        /*Pracownik p1 = new Pracownik(20);
        p1.wypisz();
        Szef s1 = new Szef(20,15);
        s1.wypisz();*/
        /*Trojkat t1 = new Trojkat(1);
        t1.pobierz();
        t1.pokarz();*/
        /*Trojkat t[] = new Trojkat[10];
        for(int i=0;i<10;i++)
        {
            t[i]= new Trojkat(i);
        }
        for (int i=0;i<3;i++)
        {
            //t[i].pobierz();
            //t[i].pokarz();
        }
        int tab[] = new int[10];
        for(int i=0;i<10;i++)
        {
            tab[i]=i;
            System.out.println(tab[i]);
        }*/
        //Teksty.wczytaj();
        //Teksty.wyswietl();
        //Teksty.przesun();
        //Teksty.eachchar();
    }
}
