package przygotowania;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Scanner;



public class Teksty {
    public static void main(String[] args) {
        wczytaj();
        wyswietl();
    }
    private static String tekst;
    private static String wynik = "";
    private static int liczby[]={1,2,6,4,5};
    static void wczytaj()
    {
        Scanner scanner = new Scanner(System.in);
        tekst = scanner.nextLine();
    }
    static void wyswietl()
    {
        System.out.println(tekst);
    }
    static void przesun()
    {
        Scanner scanner = new Scanner(System.in);
        int pom = scanner.nextInt();
        char znak;
        System.out.println(pom);

        for (int i=0;i<tekst.length();i++)
        {
            znak = (char)((int)tekst.charAt(i) + pom);
            if (  znak > 'z' || (znak > 'Z' && znak < 'a'))
            {
                znak = (char)((int)tekst.charAt(i) - 25);
            }
            tekst = tekst.replace(tekst.charAt(i),znak);
            System.out.print(tekst.charAt(i));
            wynik = wynik + tekst.charAt(i);
        }
        System.out.println();
        System.out.println(wynik);
    }

    static void each()
    {
        for (int i:liczby)
        {
            System.out.println(i);
        }
        Arrays.sort(liczby);
        System.out.println();
        for (int i:liczby)
        {
            System.out.println(i);
        }
    }
    static void eachchar()
    {
        for(char i:tekst.toCharArray())
        {
            System.out.println(i);
        }
    }

}
