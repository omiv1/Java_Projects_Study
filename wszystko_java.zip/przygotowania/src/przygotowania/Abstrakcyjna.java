package przygotowania;

import java.util.Scanner;

public abstract class Abstrakcyjna {
    private int rozmiar;

    public Abstrakcyjna(int rozmiar) {
        this.rozmiar = rozmiar;
    }
}
