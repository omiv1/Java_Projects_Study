package przygotowania;


import przygotowania.Pracownik;

public class Szef extends Pracownik
{
    private int rozmiar;

    public Szef(int wiek, int rozmiar) {
        super(wiek);
        this.rozmiar = rozmiar;
    }

    public void wypisz() {
        System.out.println("metoda szef");

    }
}
