package kolokwium2_Lukasz_Oleksiuk;

public class Pod_c {
    public String miasto;
    public String data;
    public int miejsce;
    public int liczba;

    public Pod_c(String miasto, String data, int miejsce) {
        this.miasto = miasto;
        this.data = data;
        this.miejsce = miejsce;
        liczba = 1;
    }

    public String getMiasto() {
        return miasto;
    }

    public void setMiasto(String miasto) {
        this.miasto = miasto;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public int getMiejsce() {
        return miejsce;
    }

    public void setMiejsce(int miejsce) {
        this.miejsce = miejsce;
    }

    public int getLiczba() {
        return liczba;
    }

    public void setLiczba(int liczba) {
        this.liczba = liczba;
    }
    public void show()
    {
        System.out.println(miasto+" "+data+" "+miejsce+"  liczba powtorzen: "+liczba);
    }
    public void dodaj()
    {
        liczba++;
    }
}
