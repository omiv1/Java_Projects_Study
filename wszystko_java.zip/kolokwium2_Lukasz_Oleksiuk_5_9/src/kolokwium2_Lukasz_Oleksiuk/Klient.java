package kolokwium2_Lukasz_Oleksiuk;

public class Klient extends Czlowiek
{
    public String email;
    public String miasto;
    public String godzina_od;
    public String cena_w;
    public double cena_l;
    public int numer;

    public Klient(int id, String imie, String nazwisko, String email, String miasto, String godzina_od, String cena_w,double cena_l, int numer) {
        super(id, imie, nazwisko);
        this.email = email;
        this.miasto = miasto;
        this.godzina_od = godzina_od;
        this.cena_w = cena_w;
        this.cena_l = cena_l;
        this.numer = numer;
    }
    public void show()
    {
        System.out.println(id+" "+imie+" "+nazwisko+" "+email+" "+miasto+" "+godzina_od+" "+cena_w+" "+numer);
    }
    public String show_s()
    {
        return id+" "+imie+" "+nazwisko+" "+email+" "+miasto+" "+godzina_od+" "+cena_w+" "+numer;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMiasto() {
        return miasto;
    }

    public void setMiasto(String miasto) {
        this.miasto = miasto;
    }

    public String getGodzina_od() {
        return godzina_od;
    }

    public void setGodzina_od(String godzina_od) {
        this.godzina_od = godzina_od;
    }

    public String getCena_w() {
        return cena_w;
    }

    public void setCena_w(String cena_w) {
        this.cena_w = cena_w;
    }

    public int getNumer() {
        return numer;
    }

    public void setNumer(int numer) {
        this.numer = numer;
    }

    public double getCena_l() {
        return cena_l;
    }

    public void setCena_l(double cena_l) {
        this.cena_l = cena_l;
    }
}
