package kolokwium2_Lukasz_Oleksiuk;

public class Pod_b
{
    public String miasto;
    public int liczba;

    public Pod_b(String miasto) {
        this.miasto = miasto;
        liczba=1;
    }

    public String getMiasto() {
        return miasto;
    }

    public void setMiasto(String miasto) {
        this.miasto = miasto;
    }

    public int getLiczba() {
        return liczba;
    }

    public void setLiczba(int liczba) {
        this.liczba = liczba;
    }
    public void dodaj()
    {
        liczba++;
    }
    public void show()
    {
        System.out.println(miasto+" "+liczba);
    }
}
