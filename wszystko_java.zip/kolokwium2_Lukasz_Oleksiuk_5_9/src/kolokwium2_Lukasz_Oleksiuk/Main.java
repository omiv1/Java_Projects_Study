package kolokwium2_Lukasz_Oleksiuk;

import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        File plik = new File("loty.txt");
        File plik2 = new File("wyniki.txt");
        Scanner scanner = new Scanner(plik);
        BufferedWriter writer = new BufferedWriter(new FileWriter(plik2));
        String linia;
        String podzial[];
        linia = scanner.nextLine();
        ArrayList<Klient> klients = new ArrayList<Klient>();
        while (scanner.hasNextLine())
        {
            linia = scanner.nextLine();
            podzial = linia.split(",");
            klients.add(new Klient(Integer.parseInt(podzial[0]),podzial[1],podzial[2],podzial[3],podzial[4],podzial[5],podzial[6],Double.parseDouble(podzial[6].substring(1)),Integer.parseInt(podzial[7])));
        }
        scanner.close();

        //a
        System.out.println("podpunt a\n");
        klients.sort(Comparator.comparing(Klient::getCena_l).thenComparing(Klient::getEmail));
        for(int i=0;i<klients.size();i++)
        {
            klients.get(i).show();
        }
        System.out.println("\n");

        //b
        System.out.println("podpunt b\n");
        int pom=0;
        LinkedList<Pod_b> powtorzenia = new LinkedList<Pod_b>();
        for(int i=0;i<klients.size();i++)
        {
            for (int j = 0; j < powtorzenia.size(); j++)
            {

                if (powtorzenia.get(j).getMiasto().equals(klients.get(i).getMiasto())) {
                    powtorzenia.get(j).dodaj();
                    pom = 1;

                }
            }
            if(pom==0)
            {
                powtorzenia.add(new Pod_b(klients.get(i).getMiasto()));
            }
            pom=0;

        }
        powtorzenia.sort(Comparator.comparing(Pod_b::getLiczba));
        for(Pod_b pb : powtorzenia)
        {
            pb.show();
        }
        System.out.println("\n");

        //c
        System.out.println("podpunt c\n");
        pom=0;
        LinkedList<Pod_c> duplikaty = new LinkedList<Pod_c>();
        for(int i=0;i<klients.size();i++)
        {
            for (int j = 0; j < duplikaty.size(); j++)
            {

                if (duplikaty.get(j).getMiasto().equals(klients.get(i).getMiasto()) && duplikaty.get(j).getData().equals(klients.get(i).getGodzina_od()) && duplikaty.get(j).getMiejsce() == klients.get(i).getNumer()) {
                    duplikaty.get(j).dodaj();
                    pom = 1;

                }
            }
            if(pom==0)
            {
                duplikaty.add(new Pod_c(klients.get(i).getMiasto(),klients.get(i).getGodzina_od(),klients.get(i).getNumer()));
            }
            pom=0;

        }
        duplikaty.sort(Comparator.comparing(Pod_c::getLiczba).reversed());
        for(Pod_c pc : duplikaty)
        {
            if(pc.getLiczba() > 1)
            {
                pc.show();
            }
        }

        System.out.println("\n");

        //d
        System.out.println("podpunt d\n");
        for(Klient kl : klients)
        {
            if(kl.getCena_l()>310 && kl.getMiasto().equals("Londyn"))
            {
                kl.show();
                writer.write(kl.show_s());
                writer.newLine();
            }
        }
        writer.close();

    }
}