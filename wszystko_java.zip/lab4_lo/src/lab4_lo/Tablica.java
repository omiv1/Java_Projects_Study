package lab4_lo;

import java.text.DecimalFormat;

public class Tablica {
    public static void main(String[] args) {
        //zwroc_tablice();
        int [] tablica = zwroc_tablice();
        wyswietl_tablice(tablica);
    }
    public  static int[] zwroc_tablice()
    {
        int [] liczby = new int[100];
        for(int i=0;i<liczby.length;i++)
        {
            liczby[i] = i;
            System.out.println("liczby["+i+"] = "+liczby[i]);
        }
        return liczby;
    }
    public  static void wyswietl_tablice(int[] tablica)
    {
        int [] suma_kolumn = new int[10];
        for (int i=0;i<tablica.length;i++)
        {
            DecimalFormat decimal_format = new DecimalFormat("00");
            System.out.printf(decimal_format.format(tablica[i])+", ");
            if(i>0 && (i+1)%10 == 0)
            {
                System.out.println();
            }
            int numer_kolumny = i % 10;
            suma_kolumn[numer_kolumny] += tablica[i];
        }
        System.out.println("**************************************");
        for (int liczby:suma_kolumn)
        {
            int srednia = liczby/10;
            System.out.printf(srednia+", ");
        }
    }

}
