package lab4_lo;

import java.util.Random;

public class Tablica2 {
    public  static int[][] zrobtablice()
    {
        Random random = new Random();
        int rozmiar = random.nextInt(11) + 10; //(max-min)+min;
        int tablica[][] = new int[rozmiar][rozmiar];
        for(int i=0;i<rozmiar;i++)
        {
            for(int j=0;j<rozmiar;j++)
            {
                if (i==j)
                {
                    int wylisowana = random.nextInt(2);
                    tablica[i][j] = wylisowana>0? 1:-1;
                    System.out.printf("%d ",tablica[i][j]);
                }
                tablica[i][j]= random.nextInt(42)-20;
                System.out.printf("%d ",tablica[i][j]);
            }
            System.out.println();
        }
        return tablica;
    }
    public static double suma(int [][] tablica)
    {
        double sumaliczbP=0;
        double sumaliczbN=0;
        for(int i=0;i<tablica.length;i++)
        {
            for(int j=0;j<tablica.length;j++)
            {
                if(j%2==0)
                {
                    sumaliczbP += tablica[i][j];
                }
                else sumaliczbN += tablica[i][j];
            }
        }
        System.out.printf("suma liczb parzystych = %.2f suma liczb nieparzystych = %.2f\n",sumaliczbP,sumaliczbN);
        return sumaliczbP/sumaliczbN;
    }
}
