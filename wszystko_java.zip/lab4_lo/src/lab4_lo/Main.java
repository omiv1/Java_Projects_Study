package lab4_lo;

public class Main {
    public static void main(String[] args)
    {
        int tablica[][] = Tablica2.zrobtablice();
        double res = Tablica2.suma(tablica);
        System.out.printf("%.4f",res);

    }
}