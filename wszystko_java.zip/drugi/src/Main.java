public class Main {
    System.out.println("Hello world!");
}
