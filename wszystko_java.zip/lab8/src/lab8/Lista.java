package lab8;

import java.util.ArrayList;

public class Lista {
    public static void main(String[] args) {
        ArrayList<String> lista = new ArrayList<>();
        lista.add("p1");
        lista.add("p2");
        lista.add("p3");

        wypisz(lista,(String s)->{
            System.out.println(s);
        });
    }
    public static void wypisz(ArrayList<String> przedmioty, Zadanie1 inter)
    {
        for (String s : przedmioty)
        {
            inter.przyjmij(s);
        }
    }
}
