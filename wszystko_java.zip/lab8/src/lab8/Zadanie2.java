package lab8;

import java.util.ArrayList;
import java.util.List;

public class Zadanie2 {
    public static void main(String[] args) {
        ArrayList<Integer> liczby = new ArrayList<>(List.of(10,2,3,7,3,5,6,1,2,8));
        Zadanie2 z = new Zadanie2();
        z.sortuj(liczby);
        System.out.println(liczby);
    }
    public void sortuj(ArrayList<Integer> liczby)
    {
        liczby.sort((t1,t2)->{
            if(t1==null && t2==null) return 0;
            if(t1==null) return -1;
            if(t2==null) return 1;
            if(t1.equals(t2)) return 0;
            if(t1 > t2) return 1;
            if(t1 < t2) return -1;
            return 0;
        });
    }
}
