package lab8;

public interface Zadanie1
{
    void przyjmij(String napis);
}
