package lab6;
import java.util.InputMismatchException;
import java.util.Scanner;

public class kalkulator {
    private static double a,b;
    private static char znak;
    static void wczytaj()
    {
        Scanner scan = new Scanner(System.in);
        String dzialanie;
        boolean blad = true;
        do {
            try {
                System.out.println("podaj pierwsza liczbe:");
                dzialanie = scan.nextLine();
                a = Double.parseDouble(dzialanie);
                System.out.println("podaj druga liczbe:");
                dzialanie = scan.nextLine();
                b = Double.parseDouble(dzialanie);
                blad = false;
            }catch (NumberFormatException e)
            {
                System.out.println("podaj poprawne dane");
            }
        } while (blad);
    }
    static void kalkulator()
    {
        Scanner scan = new Scanner(System.in);
        System.out.println("operacja:");
        System.out.println("+ lub - lub * lub / lub ^ lub p");
        znak = scan.next().charAt(0);
        switch (znak)
        {
            case ('+'):
                System.out.println(a+b);break;
            case ('-'):
                System.out.println(a-b);break;
            case  ('*'):
                System.out.println(a*b);break;
            case ('/'):
                System.out.println(a/b);break;
            case ('^'):
                System.out.println(Math.pow(a,b));break;
            case ('p'):
                System.out.println(Math.pow(a,1/b));break;

        }

    }
}
