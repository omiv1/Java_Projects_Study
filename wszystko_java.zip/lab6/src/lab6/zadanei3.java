package lab6;

public class zadanei3 {
    private static int liczba;


    public  static void suma(int a)
    {
        if(a <99 || a>999)
        {
            throw new IllegalArgumentException("niepoprawne dane");
        }
        int s=0;
        while (a>0)
        {
            int temp = a%10;
            s = s+(temp*temp);
            a= a/10;
        }
        System.out.println(s);
    }
}
