package lab6;

import java.awt.desktop.AboutEvent;
import java.util.Scanner;

public class zadanie2 {
    private static String liczba;

    static void wczytaj()
    {
        Scanner scan = new Scanner(System.in);
        boolean blad = true;
        do {
            try {
                System.out.println("podaj liczbe:");
                liczba = scan.nextLine();
                Double.parseDouble(liczba);

                blad = false;
            }catch (NumberFormatException e)
            {
                System.out.println("podaj poprawne dane");
            }
        } while (blad);
    }
    public static void podziel()
    {
        String tab[] = liczba.split("\\.");
        System.out.println(tab[0]+" "+tab[1]);
        double cecha=Double.parseDouble(tab[0]);
        double mantysa=Double.parseDouble(tab[1]);
        double wynik = cecha/mantysa;
        System.out.println("wynik: "+wynik);
    }
}
