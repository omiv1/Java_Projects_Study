package lab6;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
      //kalkulator.wczytaj();
      //kalkulator.kalkulator();
        //zadanie2.wczytaj();
        //zadanie2.podziel();
    zadanei3.suma(444);
    }

}